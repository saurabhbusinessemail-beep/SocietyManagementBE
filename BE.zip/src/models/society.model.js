const mongoose = require('mongoose');

const SocietySchema = new mongoose.Schema({
  name: { type: String, required: true },
  gpsLocation: { type: mongoose.Schema.Types.Mixed },
  numberOfBuildings: { type: Number },

  // governance / contact
  adminContact: { type: String },
  contactEmail: { type: String },

  // settings or preferences for the society
  settings: { type: mongoose.Schema.Types.Mixed },

  // lists of related ids kept as strings
  buildingIds: [{ type: String }]
}, { timestamps: true });

module.exports = mongoose.model('Society', SocietySchema);
