// scripts/seedRoleMenus.js
const { SocietyRoleMenu } = require('../models');

const roleMenus = [
  {
    role: 'societyadmin',
    menus: [
      { menuId: 'society', sortOrder: 1 },
      { menuId: 'complaints', sortOrder: 2 },
      { menuId: 'announcements', sortOrder: 3 },
      { menuId: 'unApprovedSocieties', sortOrder: 4 }
    ]
  },

  /* -------------------------- MANAGER -------------------------- */
  {
    role: 'manager',
    menus: [
      { menuId: 'society', sortOrder: 1 },
      { menuId: 'complaints', sortOrder: 2 },
      { menuId: 'announcements', sortOrder: 3 },
      { menuId: 'unApprovedSocieties', sortOrder: 4 }
    ]
  },

  /* -------------------------- OWNER -------------------------- */
  {
    role: 'owner',
    menus: [
      { menuId: 'myflats', sortOrder: 1 },
      { menuId: 'visitors', sortOrder: 2 },
      { menuId: 'complaints', sortOrder: 3 },
      { menuId: 'gatepass', sortOrder: 4 },
      { menuId: 'tenants', sortOrder: 5 },
      { menuId: 'members', sortOrder: 6 },
      { menuId: 'announcements', sortOrder: 7 },
      { menuId: 'vehicle', sortOrder: 8 },
      { menuId: 'unApprovedSocieties', sortOrder: 9 }
    ]
  },

  /* -------------------------- TENANT -------------------------- */
  {
    role: 'tenant',
    menus: [
      { menuId: 'myflats', sortOrder: 1 },
      { menuId: 'visitors', sortOrder: 2 },
      { menuId: 'complaints', sortOrder: 3 },
      { menuId: 'gatepass', sortOrder: 4 },
      { menuId: 'members', sortOrder: 5 },
      { menuId: 'announcements', sortOrder: 6 },
      { menuId: 'vehicle', sortOrder: 7 },
      { menuId: 'unApprovedSocieties', sortOrder: 8 }
    ]
  },

  /* -------------------------- MEMBER -------------------------- */
  {
    role: 'member',
    menus: [
      { menuId: 'myflats', sortOrder: 1 },
      { menuId: 'visitors', sortOrder: 2 },
      { menuId: 'complaints', sortOrder: 3 },
      { menuId: 'gatepass', sortOrder: 4 },
      { menuId: 'members', sortOrder: 5 },
      { menuId: 'announcements', sortOrder: 6 },
      { menuId: 'vehicle', sortOrder: 7 },
      { menuId: 'unApprovedSocieties', sortOrder: 8 }
    ]
  },

  /* -------------------------- SECURITY -------------------------- */
  {
    role: 'security',
    menus: [
      { menuId: 'society', sortOrder: 1 },
      { menuId: 'gateentry', sortOrder: 2 },
      { menuId: 'unApprovedSocieties', sortOrder: 3 }
    ]
  }
];

async function seedRoleMenus() {
  for (let rm of roleMenus) {
    const exists = await SocietyRoleMenu.findOne({ role: rm.role });
    if (!exists) {
      await SocietyRoleMenu.create(rm);
      console.log(`✔ Created role-menu mapping: ${rm.role}`);
    } else {
      // update if needed
      await SocietyRoleMenu.updateOne(
        { role: rm.role },
        { $set: { menus: rm.menus } }
      );
      console.log(`✔ Updated role-menu mapping: ${rm.role}`);
    }
  }
}

module.exports = seedRoleMenus;
