import express from 'express';
import { userAuth } from '../middlewares/auth.middleware';
import { isFlatMember } from '../middlewares/flat.middleware';
import * as flatController from '../controllers/flat.controller';

const router = express.Router();
router.use(userAuth);

router.get('/myFlats', flatController.myFlats);

router.get('/get/:flatId', flatController.getFlatById);

router.get('/:societyId/myFlats', flatController.myFlats);

router.get('/myFlats/:flatMemberId', isFlatMember, flatController.flatMember);

router.post('/myTenants', flatController.myTenants);

router.post('/myFlatMembers', flatController.myFlatMembers);

router.patch('/updatedeleteFlatMemberLeaseEnd/:flatMemberId', flatController.updatedeleteFlatMemberLeaseEnd);

router.patch('/moveInTenant/:flatMemberId', flatController.moveInTenant);

router.patch('/moveOutTenant/:flatMemberId', flatController.moveOutTenant);

router.patch('/moveOutOwner/:flatMemberId', flatController.moveOutOwner);

router.patch('/moveInSelf/:flatMemberId', flatController.moveInSelf);

router.delete('/deleteFlatMember/:flatMemberId', flatController.deleteFlatMember);

export default router;
