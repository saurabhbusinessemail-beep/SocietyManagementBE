const flatService = require('../services/flat.service');
import { flatLimitExceeded } from '../middlewares/featureGuard.middleware';

export const createFlat = async (req, res, next) => {
  try {
    const data = await flatService.createFlat(req.body);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const bulkCreateFlats = async (req, res, next) => {
  try {
    const societyId = req.params.societyId;
    const user = res.locals.user;
    if (!user || !user._id) {
      return res.status(403).json({
        message: 'Access denied: no user identified.'
      });
    }

    
    let flats = req.body;

    const limitError = await flatLimitExceeded(societyId, flats.length);
    if (limitError) {
      return res.status(403).json(limitError);
    }

    flats.forEach((flat) => {
      societyId,
        flat.createdOn = new Date();
      flat.createdByUserId = user._id;
    });
    const data = await flatService.bulkCreateFlats(flats);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const getFlatsBySocietyAndBuilding = async (req, res, next) => {
  try {
    const societyId = req.params.societyId;
    const buildingId = req.params.buildingId;
    const { page, limit } = req.query;

    let filter = {
      ...(res.locals.filter ?? {}),
      societyId
    };
    if (buildingId) filter['buildingId'] = buildingId;

    const data = await flatService.getFlatsBySocietyAndBuilding(filter, {
      page: Number(page),
      limit: Number(limit)
    });
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const getFlatsCountBySocietyAndBuilding = async (req, res, next) => {
  try {
    const societyId = req.params.societyId;
    const buildingId = req.params.buildingId;

    let filter = {
      ...(res.locals.filter ?? {}),
      societyId
    };
    if (buildingId) filter['buildingId'] = buildingId;

    const data = await flatService.getFlatsCountBySocietyAndBuilding(filter);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const getFlatById = async (req, res, next) => {
  try {
    const data = await flatService.getFlatById(req.params.flatId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const updateFlat = async (req, res, next) => {
  try {
    const data = await flatService.updateFlat(req.params.societyId, req.body);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const deleteFlat = async (req, res, next) => {
  try {
    const data = await flatService.deleteFlat(req.params.flatId);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

export const myFlats = async (req, res, next) => {
  try {
    const societyId = req.params.societyId;
    const data = await flatService.myFlats(res.locals.user._id, societyId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const flatMember = async (req, res, next) => {
  try {
    const flatMemberId = req.params.flatMemberId;
    const data = await flatService.flatMember(flatMemberId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const updatedeleteFlatMemberLeaseEnd = async (req, res, next) => {
  try {
    const flatMemberId = req.params.flatMemberId;
    const { endDate } = req.body;
    const data = await flatService.updatedeleteFlatMemberLeaseEnd(flatMemberId, endDate, res.locals.user._id);
    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
};

export const moveOutTenant = async (req, res, next) => {
  try {
    const userId = res.locals.user?._id;
    if (!userId) return res.json({ success: false, message: 'User not found!' });

    const flatMemberId = req.params.flatMemberId;
    const { endDate = new Date() } = req.body;
    const data = await flatService.moveOutTenant(flatMemberId, endDate, userId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const moveInTenant = async (req, res, next) => {
  try {
    const userId = res.locals.user?._id;
    if (!userId) return res.json({ success: false, message: 'User not found!' });

    const flatMemberId = req.params.flatMemberId;
    const { endDate = new Date() } = req.body;
    const data = await flatService.moveInTenant(flatMemberId, userId, endDate);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const moveOutOwner = async (req, res, next) => {
  try {
    const userId = res.locals.user?._id;
    if (!userId) return res.json({ success: false, message: 'User not found!' });

    const flatMemberId = req.params.flatMemberId;
    const data = await flatService.moveOutOwner(flatMemberId, userId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const moveInSelf = async (req, res, next) => {
  try {
    const userId = res.locals.user?._id;
    if (!userId) return res.json({ success: false, message: 'User not found!' });

    const flatMemberId = req.params.flatMemberId;
    const data = await flatService.moveInSelf(flatMemberId, userId);
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const deleteFlatMember = async (req, res, next) => {
  try {
    const data = await flatService.deleteFlatMember(req.params.flatMemberId);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};

export const myTenants = async (req, res, next) => {
  try {
    const { societyId, flatId } = req.body;
    const { page, limit } = req.query;
    const data = await flatService.myTenants(res.locals.user._id, societyId, flatId, {
      page: Number(page),
      limit: Number(limit)
    });
    res.json(data);
  } catch (err) {
    next(err);
  }
};

export const myFlatMembers = async (req, res, next) => {
  try {
    const socities = res.locals.socities;
    const { societyId, flatId } = req.body;
    const { page, limit } = req.query;

    const data = await flatService.myFlatMembers(res.locals.user._id, societyId, flatId, socities, {
      page: Number(page),
      limit: Number(limit)
    });
    res.json(data);
  } catch (err) {
    console.log('err = ', err);
    next(err);
  }
};
